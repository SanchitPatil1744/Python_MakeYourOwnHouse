from tkinter import *

cd_login_window = Tk()
cd_login_window.title("Sign In")
cd_login_window.geometry('1366x768')

def nextPagetoHome():
    cd_login_window.destroy()
    import HomePage


def nextPagetoSignUp():
    cd_login_window.destroy()
    import signup


def username_enter(event):
    if username_entry.get() == 'Username':
        username_entry.delete(0, END)


def password_enter(event):
    if password_entry.get() == 'Password':
        password_entry.delete(0, END)

# Heading Label
cd_head_lbl = Label(cd_login_window, text='USER LOGIN', font=('Times New Roman', 30, 'bold'), bg='white',
                    fg='firebrick1')
cd_head_lbl.place(x=475, y=120)

# Username input TextField
username_entry = Entry(cd_login_window, width=25, font=('Times New Roman', 20, 'bold'), bd=0, fg='firebrick1')
username_entry.place(x=420, y=240)
username_entry.insert(0, 'Username')
username_entry.bind('<FocusIn>', username_enter)

# Username line for TextField
Frame(cd_login_window, width=430, height=2, bg='firebrick1').place(x=420, y=285)

# Password input TextField
password_entry = Entry(cd_login_window, width=25, font=('Times New Roman', 20, 'bold'), bd=0, fg='firebrick1')
password_entry.place(x=420, y=335)
password_entry.insert(0, 'Password')
password_entry.bind('<FocusIn>', password_enter)

# Password line for TextField
Frame(cd_login_window, width=430, height=2, bg='firebrick1').place(x=420, y=380)

# Button
cd_login_btn = Button(cd_login_window, text='LOGIN', font=('Open Sans', 20, 'bold'), fg='white', bg='firebrick1',
                      activeforeground='white', activebackground='firebrick1', cursor='hand2', bd=0, width=25, height=1,
                      command=nextPagetoHome)
cd_login_btn.place(x=420, y=450)

# Signup
cd_sign_up_lbl = Label(cd_login_window, text="Don't have an account?", font=('Open sans', 15, 'bold'), fg='firebrick1',
                       bg='white')
cd_sign_up_lbl.place(x=400, y=550)
cd_new_acc_btn = Button(cd_login_window, text='Create One Now', font=('Open Sans', 15, 'bold underline'), fg='blue',
                        bg='white', activeforeground='blue', activebackground='white', cursor='hand2', bd=0,
                        command=nextPagetoSignUp)
cd_new_acc_btn.place(x=730, y=545)

cd_login_window.mainloop()