from tkinter import *
from tkinter import ttk

from PIL import Image, ImageTk





def nextPagetoConstruct():
    material_page.destroy()
    import Construct


def calculate():
    floor = comboa.get()
    space = combo2.get()
    qual = combo3.get()
    xy = 1
    if qual == 1 :
        xy = 1.32
    elif qual == 2 :
        xy = 1
    if qual == 3 :
        xy = 0.70
    concrete = int(floor) * int(space) * 700 + 50
    txtfld1a.config(text="{} kg".format(concrete))
    brick = int(floor) * int(space) * 600 + 65
    txtfld1b.config(text="{} kg".format(brick))
    steel = int(floor) * int(space) * 1000 + 65
    txtfld1c.config(text="{} kg".format(steel))
    glass = int(floor) * int(space) * 100 + 5
    txtfld1d.config(text="{} kg".format(glass))
    wood = int(floor) * int(space) * 250 + 50
    txtfld2a.config(text="{} kg".format(wood))
    tiles = int(floor) * int(space) * 100
    txtfld2b.config(text="{} kg".format(tiles))
    stones = int(floor) * int(space) * 400 + 65
    txtfld2c.config(text="{} kg".format(stones))
    aagr = int(floor) * int(space) * 390 + 70
    txtfld2d.config(text="{} kg".format(aagr))
    cost = (int(concrete) * 50 + int(brick) * 45 + int(steel) * 100 + int(glass) * 150 + int(wood) * 30 + int(
        tiles) * 200 + int(stones) * 40 + int(aagr) * 50) * int(qual)/2
    txtfld3a.config(text="Rs {}".format(cost))




# Create the Tkinter home_page and run the application
material_page = Tk()
material_page.geometry('1366x768')
# heading

lbl1 = Label(material_page, text="Quality", fg='red', font=("Helvetica", 26))
lbl1.place(x=30, y=30)
# combobox
options = ["1", "2", "3"]
combo3 = ttk.Combobox(state="readonly", values=options, font=("Helvetica", 19))
combo3.place(x=490, y=30)

# label to be construced
lbl1 = Label(material_page, text="Floors to be constructed", fg='red', font=("Helvetica", 26))
lbl1.place(x=30, y=90)
# combobox
options = ["1", "2", "3", "4"]
comboa = ttk.Combobox(state="readonly", values=options, font=("Helvetica", 19))
comboa.place(x=490, y=90)

# label house space
lbl3 = Label(material_page, text="House Space (in BHK)", fg='red', font=("Helvetica", 26))
lbl3.place(x=30, y=150)
# combobox
combo2 = ttk.Combobox()
options = ["1", "2", "3"]
combo2 = ttk.Combobox(state="readonly", values=options, font=("Helvetica", 19))
combo2.place(x=490, y=150)
# 1a
lbl1a = Label(material_page, text="Concrete", fg='black', font=("Helvetica", 26))
lbl1a.place(x=30, y=210)
txtfld1a = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld1a.place(x=250, y=210, height=40, width=130)
# 1b
lbl1b = Label(material_page, text="Brick", fg='black', font=("Helvetica", 26))
lbl1b.place(x=30, y=290)
txtfld1b = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld1b.place(x=250, y=290, height=40, width=130)
# 1c
lbl1c = Label(material_page, text="Steel", fg='black', font=("Helvetica", 26))
lbl1c.place(x=30, y=370)
txtfld1c = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld1c.place(x=250, y=370, height=40, width=130)
# 1d
lbl1d = Label(material_page, text="Glass", fg='black', font=("Helvetica", 26))
lbl1d.place(x=30, y=450)
txtfld1d = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld1d.place(x=250, y=450, height=40, width=130)
# 2a
lbl2a = Label(material_page, text="Wood", fg='black', font=("Helvetica", 26))
lbl2a.place(x=530, y=210)
txtfld2a = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld2a.place(x=750, y=210, height=40, width=130)
# 2b
lbl2b = Label(material_page, text="Tiles", fg='black', font=("Helvetica", 26))
lbl2b.place(x=530, y=290)
txtfld2b = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld2b.place(x=750, y=290, height=40, width=130)
# 2c
lbl2c = Label(material_page, text="Stones", fg='black', font=("Helvetica", 26))
lbl2c.place(x=530, y=370)
txtfld2c = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld2c.place(x=750, y=370, height=40, width=130)
# 2d
lbl2d = Label(material_page, text="Aggregate", fg='black', font=("Helvetica", 26))
lbl2d.place(x=530, y=450)
txtfld2d = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld2d.place(x=750, y=450, height=40, width=130)

lbl3a = Label(material_page, text="Cost(rs)", fg='black', font=("Helvetica", 26))
lbl3a.place(x=750, y=560)
txtfld3a = Label(material_page, text="", fg='blue', font=("Helvetica", 26))
txtfld3a.place(x=900, y=560, height=40, width=250)

# creating button estimate
btn1b = Button(material_page, text='Estimate', font=('Open Sans', 20, 'bold'), fg='white', bg='firebrick1',
               activeforeground='white', activebackground='firebrick1', cursor='hand2', bd=0, width=15, height=1,
               command=calculate)
btn1b.place(x=900, y=110)

btnback = Button(material_page, text='Back', font=('Open Sans', 20, 'bold'), fg='white', bg='firebrick1',
                 activeforeground='white', activebackground='firebrick1', cursor='hand2', bd=0, width=8, height=1,
                 command=nextPagetoConstruct)
btnback.place(x=1200, y=10)

material_page.mainloop()
