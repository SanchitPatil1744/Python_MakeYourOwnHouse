from tkvideo import tkvideo
from tkinter import *

w = Tk()
lblVideo = Label(w)
lblVideo.pack()

player = tkvideo("D:\\SanchitSanjayPatil\\Coding\\Clg\\sem4\\make-your-own-house\\images\\Hall_1.mp4", lblVideo,
                     loop=1,
                     size=(700, 500))
player.play()

w.mainloop()




