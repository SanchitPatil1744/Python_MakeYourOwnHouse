cd_bg_image = ImageTk.PhotoImage(file='../resources/images_resources/sign_in.jpeg')
cd_bg_label = Label(sign_in_window, image=cd_bg_image)
cd_bg_label.place(x=0, y=0)