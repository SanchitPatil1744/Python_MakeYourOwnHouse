import tkinter as tk

root = tk.Tk()

# create a Canvas widget with the same size as the root window
canvas = tk.Canvas(root, width=root.winfo_screenwidth(), height=root.winfo_screenheight())
canvas.pack()

# create a PhotoImage object from the image file
image = tk.PhotoImage(file="Plans.png")

# use the create_image method to draw the image on the canvas
canvas.create_image(0, 0, image=image, anchor=tk.NW)

# create other widgets on top of the canvas as needed
label = tk.Label(root, text="Hello, world!", font=("Arial", 20))
label.pack()

root.mainloop()