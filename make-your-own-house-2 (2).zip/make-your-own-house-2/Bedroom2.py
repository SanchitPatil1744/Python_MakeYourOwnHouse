from tkinter import *

from PIL import Image, ImageTk


class App(Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.pack(fill=BOTH, expand=YES)

        # Load the image
        self.image = Image.open('images/Bedroom_2.png')
        self.photo = ImageTk.PhotoImage(self.image)

        # Create the background label and pack it
        self.background_label = Label(self, image=self.photo)
        self.background_label.pack(fill=BOTH, expand=YES)



def nextPagetoConstruct():
    bhk11.destroy()
    import Plans1


bhk11 = Tk()
bhk11.geometry('500x500')

app = App(bhk11)

btnback = Button(bhk11, text='Back', font=('Open Sans', 20, 'bold'), fg='white', bg='firebrick1',
                 activeforeground='white', activebackground='firebrick1', cursor='hand2', bd=0, width=8, height=1,
                 command=nextPagetoConstruct)
btnback.place(x=350, y=10)

bhk11.mainloop()