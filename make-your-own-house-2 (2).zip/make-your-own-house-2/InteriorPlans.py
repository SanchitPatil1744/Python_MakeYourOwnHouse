from tkinter import *

from PIL import Image, ImageTk
import tkvideo as tkvideo

class App(Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.pack(fill=BOTH, expand=YES)

        # Load the image
        self.image = Image.open('images/Plans.png')
        self.photo = ImageTk.PhotoImage(self.image)

        # Create the background label and pack it
        self.background_label = Label(self, image=self.photo)
        self.background_label.pack(fill=BOTH, expand=YES)

        # Allow the user to fit the image to the intplans_page size
        self.bind("<Configure>", self.resize)

    def resize(self, event):
        # Resize the image
        self.image = self.image.resize((event.width, event.height))
        self.photo = ImageTk.PhotoImage(self.image)
        self.background_label.config(image=self.photo)


def nextPagetoInterior():
    intplans_page.destroy()
    import InteriorDesign


def VideoHall1():
    intplans_page.destroy()
    import Hall1

def VideoHall2():
    intplans_page.destroy()
    import Hall2

def VideoHall3():
    intplans_page.destroy()
    import Hall3

def VideoHall4():
    intplans_page.destroy()
    import Hall4

intplans_page = Tk()
app = App(intplans_page)
intplans_page.geometry('1366x768')
# heading

# functions

# main code - e.g. buttons, etc
btn = Button(intplans_page, text="Plan A", fg='blue', font=("Helvetica", 26), command=VideoHall1)
btn.place(x=180, y=180)
btn = Button(intplans_page, text="Plan B", fg='blue', font=("Helvetica", 26), command=VideoHall2)
btn.place(x=180, y=280)
btn = Button(intplans_page, text="Plan C", fg='blue', font=("Helvetica", 26), command=VideoHall3)
btn.place(x=180, y=380)
btn = Button(intplans_page, text="Plan D", fg='blue', font=("Helvetica", 26), command=VideoHall4)
btn.place(x=180, y=480)
btn = Button(intplans_page, text="Plan E", fg='blue', font=("Helvetica", 26))
btn.place(x=180, y=580)

btnback = Button(intplans_page, text='Back', font=('Open Sans', 20, 'bold'), fg='white', bg='firebrick1',
                 activeforeground='white', activebackground='firebrick1', cursor='hand2', bd=0, width=8, height=1,
                 command=nextPagetoInterior)
btnback.place(x=1200, y=10)

intplans_page.mainloop()

